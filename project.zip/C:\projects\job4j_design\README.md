   2.1.0. Maven

   2.1.1. AssertJ

   2.1.2. Iterator

   2.1.3. Generic

   2.1.4. List

   2.1.5. Set

   2.1.6. Map

   2.1.7. Tree

   2.1.8. Контрольные вопросы

   2.2.1. Ввод-вывод

   2.2.2. Socket

   2.2.3. Логгирование

   2.2.4. Сериализация

   2.2.5. Контрольные вопросы

   2.3.0. Настройка PostgreSQL
SQL, JDBC
   2.3.1. Create Update Insert
SQL, JDBC
   2.3.2. Query
SQL, JDBC
   2.3.3. Outer join
SQL, JDBC
   2.3.4. Объекты Базы данных
SQL, JDBC
   2.3.5. JDBC
SQL, JDBC
   2.3.6. Liquibase
SQL, JDBC
   2.3.7. Проект. Агрегатор Java вакансий
SQL, JDBC
   2.3.8. Контрольные вопросы
SQL, JDBC
   2.4.1. Понятие сборщик мусора
Garbage Collection
   2.4.2. Виды сборщиков мусора
Garbage Collection
   2.4.3. Профилирование приложения
Garbage Collection
   2.4.4. Типы ссылок и коллекции на soft weak ссылках
Garbage Collection
   2.4.5. Java Memory Model
Garbage Collection
   2.4.6. Контрольные вопросы
Garbage Collection
   2.5.0. TDD
ООД
   2.5.1. SRP
ООД
   2.5.2. OCP
ООД
   2.5.3. LSP
ООД
   2.5.4. ISP
ООД
   2.5.5. DIP
ООД
   2.5.6. Контрольные вопросы
ООД