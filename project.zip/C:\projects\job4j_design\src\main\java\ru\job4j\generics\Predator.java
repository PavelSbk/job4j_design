package ru.job4j.generics;

import ru.job4j.generics.Animal;

public class Predator extends Animal {

}
