package ru.job4j.generics;

import java.util.Objects;

public class Animal {
}
